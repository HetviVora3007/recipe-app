const url = "https://recipe-backend-ofe3.onrender.com/"

export default url